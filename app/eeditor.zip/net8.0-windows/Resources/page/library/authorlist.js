const authorsData = {
    eenot: {
        name: "@eenot",
        link: "https://discord.com/users/794675642037567491",
        color: "#3B83BD"
    },
    theman_the_myth_the_legend: {
        name: "@theman_the_myth_the_legend",
        link: "https://discord.com/users/1083919275951149118",
        color: "#3B83BD"
    },
    helvetic_brutalisation: {
        name: "@helvetic_brutalisation",
        link: "https://discord.com/users/1280887382920532073",
        color: "#3B83BD"
    },
    totoska: {
        name: "@totoska",
        link: "https://discord.com/users/820194328201920524",
        color: "#3B83BD"
    },
    kolkhoznik: {
        name: "@nickolay_batsiev_suleimanov",
        link: "https://discord.com/users/1057029940484247682",
        color: "#3B83BD"
    },
    esteban: {
        name: "@deleted_user",
        link: "https://discord.com/users/456226577798135808",
        color: "#FF83BD"
    },
    zachary: {
        name: "@zachary.bachary",
        link: "https://discord.com/users/804839006403428423",
        color: "#3B83BD"
    },
    pelo: {
        name: "@pelo3918",
        link: "https://discord.com/users/1071700840492056717",
        color: "#3B83BD"
    },
    atharva: {
        name: "@atharva04303",
        link: "https://discord.com/users/1306545186146353193",
        color: "#3B83BD"
    },
    bluepum: {
        name: "@blue_pum_67269",
        link: "https://discord.com/users/1260558860796825610",
        color: "#3B83BD"
    },
    radardev: {
        name: "@radardev",
        link: "https://discord.com/users/951467148063158324",
        color: "#3B83BD"
    },
    stewardconstruct: {
        name: "@stewardconstruct.",
        link: "https://discord.com/users/1114590604668706927",
        color: "#3B83BD"
    },
    trid: {
        name: "@trid9505",
        link: "https://discord.com/users/993585215358386306",
        color: "#3B83BD"
    },
    jaba: {
        name: "@jaba4275",
        link: "https://discord.com/users/921793805915668520",
        color: "#3B83BD"
    },
    parkourfox: {
        name: "@parkourfox",
        link: "https://discord.com/users/921793805915668520",
        color: "#3B83BD"
    },
    jalhund: {
        name: "@jalhund",
        link: "https://discord.com/users/277053272959008768",
        color: "#3B83BD"
    },
    chuckcha: {
        name: "@chuckha",
        link: "https://discord.com/users/896347314615123978",
        color: "#3B83BD"
    },
    jombone: {
        name: "@.jombonethegreat",
        link: "https://discord.com/users/702259308817285220",
        color: "#3B83BD"
    },
    mapmancer: {
        name: "@stilltrex",
        link: "https://discord.com/users/950707094229766174",
        color: "#3B83BD"
    },
    chitterss: {
        name: "@deleted_user",
        link: "https://discord.com/users/611870107970568214",
        color: "#3B83BD"
    },
    grimreaper: {
        name: "@grimreaper54",
        link: "https://discord.com/users/720328844464357446",
        color: "#3B83BD"
    },
}